# 📊 SATRIAMART Business Intelligence Dashboard Prototype

## Deskripsi

Dashboard prototype interaktif berbasis HTML & Tailwind CSS yang dirancang untuk memvisualisasikan implementasi Business Intelligence menggunakan Looker Studio. Dashboard ini menyajikan analisis komprehensif data bisnis SATRIAMART meliputi penjualan, produk, pelanggan, dan keuangan.

## 🎯 Tujuan

Dashboard ini dibuat sebagai **prototype visual** untuk:
1. Membantu tim memahami layout dan struktur dashboard sebelum implementasi di Looker Studio
2. Memberikan gambaran interaktif tentang visualisasi data yang akan digunakan
3. Memudahkan stakeholder dalam memberikan feedback tentang desain dan konten
4. Sebagai referensi implementasi dashboard BI menggunakan Looker Studio

## 📁 Struktur Folder

```
dashboard-prototype/
├── index.html                    # Landing page / Home
├── pages/
│   ├── executive-summary.html    # Page 1: Executive Summary
│   ├── sales-analysis.html       # Page 2: Sales Analysis
│   ├── product-performance.html  # Page 3: Product Performance
│   ├── customer-analysis.html    # Page 4: Customer Analysis
│   └── financial-analysis.html   # Page 5: Financial Analysis
├── js/                           # JavaScript files (untuk future enhancement)
└── assets/                       # Images dan assets lainnya
```

## 🌟 Fitur Dashboard

### 1. Landing Page (index.html)
- Overview singkat dashboard
- Quick stats (Total Transaksi, Revenue, Pelanggan, Produk)
- Navigasi ke semua halaman dashboard
- Fitur unggulan dashboard

### 2. Executive Summary (Page 1)
**KPI Cards:**
- Total Revenue: Rp 111.976.550
- Total Transaksi: 320
- Average Order Value: Rp 349.926
- Total Pelanggan: 180
- Order Completion Rate: 85%
- Customer Rating: 4.5/5.0

**Visualisasi:**
- Revenue Trend (Line Chart - 12 Bulan)
- Sales by Channel (Doughnut Chart)
- Revenue by Category (Bar Chart)
- Top 5 Products (List)
- Key Insights & Recommendations

### 3. Sales Analysis (Page 2)
**Metrics:**
- Total Sales: 320
- Completed Orders: 272 (85%)
- In Progress: 26 (8%)
- Cancelled: 22 (7%)

**Visualisasi:**
- Monthly Sales Performance (Line Chart)
- Sales by Channel (Bar Chart)
- Payment Method Distribution (Doughnut Chart)
- Sales by Day of Week (Bar Chart)
- Order Status Distribution (Progress Bars)
- Recent Transactions Table

### 4. Product Performance (Page 3)
**Metrics:**
- Active Products: 50
- Total Categories: 5
- Average Stock Level: 28 units
- Stock Turnover: 6.2x

**Visualisasi:**
- Top 10 Products by Revenue (Horizontal Bar Chart)
- Category Distribution (Doughnut Chart)
- Sales by Price Range (Bar Chart)
- Inventory Status (Progress Bars)
- Product Catalog Table

### 5. Customer Analysis (Page 4)
**Metrics:**
- Total Customers: 180
- Repeat Customer: 45%
- Average Customer Value: Rp 622K
- Customer Lifetime Value: Rp 1.2M

**Visualisasi:**
- Customer Segmentation (Doughnut Chart)
  - VIP: 15%
  - Loyal: 30%
  - Regular: 30%
  - One-time: 25%
- Geographic Distribution (Bar Chart + Progress Bars)
- Top 10 Customers Table

### 6. Financial Analysis (Page 5)
**Metrics:**
- Total Revenue: Rp 112M
- Total Costs: Rp 63.5M
- Net Profit: Rp 48.5M
- ROI: 76.4%

**Visualisasi:**
- Revenue vs Profit Trend (Multi-line Chart)
- Operational Costs Breakdown (Doughnut Chart)
  - Bahan Baku: 55%
  - Marketing: 18%
  - Operasional: 12%
  - Transportasi: 10%
  - Utilitas: 5%
- Profit by Category (Bar Chart)
- Monthly Cost Analysis Table
- Financial Insights

## 💻 Teknologi yang Digunakan

1. **HTML5** - Struktur halaman
2. **Tailwind CSS** - Styling dan responsive design
3. **Chart.js** - Visualisasi data (charts)
4. **Font Awesome** - Icons
5. **Google Fonts (Inter)** - Typography

## 🚀 Cara Menggunakan

### Metode 1: Langsung Buka File
1. Download/clone folder `dashboard-prototype`
2. Buka file `index.html` di web browser
3. Navigasi antar halaman melalui menu

### Metode 2: Menggunakan Local Server (Recommended)

**Untuk Laragon:**
```bash
# Dashboard sudah ada di:
# c:\laragon\www\unm-s7\tugas-selesai\05_business_intelligence\dashboard-prototype\

# Akses via browser:
http://localhost/unm-s7/tugas-selesai/05_business_intelligence/dashboard-prototype/
```

**Untuk Python Simple Server:**
```bash
cd dashboard-prototype
python -m http.server 8000

# Akses via browser:
http://localhost:8000
```

**Untuk Node.js (live-server):**
```bash
npm install -g live-server
cd dashboard-prototype
live-server
```

## 📊 Data yang Divisualisasikan

Dashboard menggunakan data sample berdasarkan:
- **Periode**: November 2024 - Oktober 2025 (12 bulan)
- **Transaksi**: 320 transaksi penjualan
- **Produk**: 50 SKU aktif
- **Pelanggan**: 180 customers
- **Revenue**: Rp 111.976.550

Data berasal dari file CSV:
- `01_master_produk.csv`
- `02_master_pelanggan.csv`
- `03_transaksi_penjualan.csv`
- `04_riwayat_stok.csv`
- `05_biaya_operasional.csv`

## 🎨 Design System

### Color Palette
- **Primary (Purple)**: #667eea → Executive Summary
- **Success (Green)**: #10b981 → Sales Analysis
- **Info (Purple)**: #8b5cf6 → Product Performance
- **Warning (Orange)**: #f59e0b → Customer Analysis
- **Danger (Red)**: #ef4444 → Financial Analysis

### Typography
- Font Family: Inter
- Heading: Bold (700-800)
- Body: Regular (400-500)

### Components
- **KPI Cards**: Border-left accent dengan icon
- **Charts**: Menggunakan Chart.js dengan custom colors
- **Tables**: Striped rows dengan hover effect
- **Buttons**: Rounded dengan smooth transitions

## 📱 Responsive Design

Dashboard dirancang responsive untuk:
- ✅ Desktop (1920px+)
- ✅ Laptop (1366px - 1920px)
- ✅ Tablet (768px - 1366px)
- ✅ Mobile (< 768px)

## 🔄 Implementasi ke Looker Studio

### Langkah-langkah:
1. **Persiapan Data**
   - Upload semua CSV ke Google Sheets
   - Format data sesuai kebutuhan (currency, date, etc.)

2. **Create Data Sources**
   - Connect Google Sheets ke Looker Studio
   - Buat blended data untuk join tables

3. **Dashboard Layout**
   - Gunakan prototype ini sebagai referensi layout
   - Buat 5 pages sesuai struktur prototype

4. **Add Visualizations**
   - Replicate semua chart dari prototype
   - Gunakan same color scheme

5. **Add Interactivity**
   - Date range control
   - Filter controls
   - Cross-filtering antar charts

6. **Testing & Refinement**
   - Test semua filter dan interaksi
   - Optimize performance
   - User acceptance testing

## 📈 Key Insights dari Dashboard

1. **Peak Season**: Desember adalah bulan dengan penjualan tertinggi (Rp 14.2M)
2. **Channel Dominan**: WhatsApp menghasilkan 45% dari total revenue
3. **Product Best Seller**: Nomor Rumah Akrilik Kayu Kombinasi (Rp 8.5M)
4. **Customer Retention**: 45% adalah repeat customers
5. **Profit Margin**: 43.3% - sangat sehat untuk industri manufaktur
6. **ROI**: 76.4% - menunjukkan efisiensi investasi yang sangat baik

## 🎯 Recommendations

Berdasarkan analisis dashboard:

1. **Sales Optimization**
   - Fokus marketing di bulan-bulan low season (Feb, Sep)
   - Optimalkan WhatsApp channel dengan automated messaging

2. **Product Strategy**
   - Tingkatkan stok produk best seller
   - Develop lebih banyak produk premium (high margin)
   - Focus pada kategori Signage (margin tertinggi)

3. **Customer Retention**
   - Implementasi loyalty program
   - Automated follow-up untuk one-time buyers
   - Special offer untuk VIP customers

4. **Financial Management**
   - Evaluasi ROI marketing per channel
   - Optimasi biaya bahan baku melalui bulk purchasing
   - Maintain profit margin di atas 40%

## 👥 Tim Penyusun

- **Roki Anjas** (11250066)
- **Fahruroji** (11250085)
- **Susanto** (11250068)

**Kelas**: 11.7C.12  
**Program Studi**: Informatika  
**Universitas**: Nusa Mandiri  
**Tahun**: 2025

## 📝 Catatan

- Dashboard ini adalah **PROTOTYPE** untuk visualisasi dan planning
- Data yang ditampilkan adalah **SAMPLE DATA** berdasarkan CSV yang telah digenerate
- Untuk implementasi production, gunakan data real-time dari database
- Chart interactivity bersifat demonstratif (tidak fully functional seperti Looker Studio)

## 🔗 Referensi

- [Laporan BI Lengkap](../laporan/LAPORAN_BI_SATRIAMART_LENGKAP.md)
- [Panduan Implementasi Looker Studio](../PANDUAN_IMPLEMENTASI.md)
- [Data CSV](../data/)

## 📄 License

Dibuat untuk keperluan akademis - Tugas Business Intelligence  
Universitas Nusa Mandiri 2025

---

**Last Updated**: November 2025  
**Version**: 1.0.0  
**Status**: ✅ Complete & Ready for Review
