# BUSINESS REQUIREMENTS DOCUMENT (BRD)
## SATRIAMART Integrated Management System (SIMS)

**Universitas Nusa Mandiri**  
**Mata Kuliah: Proyek Sistem Informasi II**  
**Dosen: Rani Irma Handayani, M.Kom**

---

## 1. EXECUTIVE SUMMARY

### 1.1 Project Overview
SATRIAMART Integrated Management System (SIMS) adalah solusi software terintegrasi yang dirancang untuk mengotomatisasi dan mengoptimalkan proses bisnis SATRIAMART dalam mengelola customer relationship, inventory, production planning, dan sales analytics.

### 1.2 Business Objectives
1. **Meningkatkan operational efficiency** sebesar 40% melalui otomasi proses
2. **Menyediakan real-time visibility** terhadap business performance
3. **Meningkatkan customer satisfaction** melalui better service delivery
4. **Membangun scalable foundation** untuk business growth

### 1.3 Scope Summary
Sistem akan mencakup 4 module utama: CRM, Inventory Management, Production Planning, dan Sales Analytics dengan integrasi penuh antar module.

---

## 2. CURRENT STATE ANALYSIS

### 2.1 Business Process Overview

#### Current SATRIAMART Operations Flow:
```
Customer Inquiry → Manual Quotation → Order Confirmation → 
Material Planning → Production Scheduling → Quality Control → 
Delivery → Payment → Customer Service
```

### 2.2 Current Pain Points

| Area | Current State | Pain Points |
|------|---------------|-------------|
| **Customer Management** | Excel spreadsheets, manual tracking | - Duplicate data entry<br>- Lost customer communications<br>- No customer history visibility |
| **Order Management** | WhatsApp + manual notes | - Order details confusion<br>- No order status tracking<br>- Manual follow-up required |
| **Inventory Management** | Physical counting + Excel | - Stock discrepancies<br>- Overstock/understock issues<br>- No automated reorder alerts |
| **Production Planning** | Manual scheduling | - Resource allocation conflicts<br>- No capacity visibility<br>- Missed delivery deadlines |
| **Sales Reporting** | Manual compilation | - Time-consuming reporting<br>- Data accuracy issues<br>- No real-time insights |

### 2.3 Current System Landscape

| Function | Current Tool | Limitations |
|----------|--------------|-------------|
| Customer Communication | WhatsApp Business | No integration, limited history |
| Order Tracking | Google Sheets | Manual updates, no automation |
| Inventory | Manual counting | No real-time visibility |
| Financial | Simple bookkeeping | No integration with operations |
| Reporting | Excel manual compilation | Time-consuming, error-prone |

---

## 3. FUNCTIONAL REQUIREMENTS

### 3.1 Customer Relationship Management (CRM)

#### 3.1.1 Customer Profile Management

**REQ-CRM-001: Customer Registration**
- **Description:** System harus dapat mendaftarkan customer baru dengan informasi lengkap
- **Functional Details:**
  - Input: Nama, alamat, telepon, email, jenis usaha
  - Automatic customer ID generation
  - Customer category classification (individual/business)
  - Validation untuk duplicate customers
- **Business Rules:**
  - Mandatory fields: Nama, telepon
  - Email harus unique jika diisi
  - Customer ID format: CUST-YYYY-NNNN
- **Acceptance Criteria:**
  - User dapat input customer data melalui form
  - System generate unique customer ID
  - Validation error messages ditampilkan jika ada duplikasi

**REQ-CRM-002: Customer Profile Management**
- **Description:** System harus dapat mengelola dan update informasi customer
- **Functional Details:**
  - View customer detail dengan history lengkap
  - Edit customer information
  - Customer status management (active/inactive)
  - Customer notes dan tags
- **Business Rules:**
  - Only authorized users can edit customer data
  - Audit trail untuk semua perubahan data
  - Soft delete untuk customer (tidak benar-benar dihapus)

#### 3.1.2 Order Management

**REQ-CRM-003: Quotation Management**
- **Description:** System harus dapat membuat dan mengelola quotation untuk customer
- **Functional Details:**
  - Create quotation dengan item details
  - Quotation approval workflow
  - Convert quotation to order
  - Quotation versioning dan history
- **Business Rules:**
  - Quotation valid untuk 30 hari default
  - Approval required untuk quotation > Rp 5,000,000
  - Automatic quotation numbering: QUO-YYYY-MM-NNNN

**REQ-CRM-004: Order Processing**
- **Description:** System harus dapat memproses order dari quotation atau direct order
- **Functional Details:**
  - Order creation dari quotation atau manual
  - Order status tracking (Draft, Confirmed, In Production, Ready, Delivered)
  - Order modification dengan approval
  - Order cancellation dengan reason
- **Business Rules:**
  - Order confirmation required dari customer
  - Down payment 50% untuk custom orders
  - Order priority based pada delivery date
- **Acceptance Criteria:**
  - Order dapat dibuat dari approved quotation
  - Status order ter-update secara real-time
  - Customer dapat melihat order status

#### 3.1.3 Communication Management

**REQ-CRM-005: Customer Communication Log**
- **Description:** System harus dapat mencatat semua komunikasi dengan customer
- **Functional Details:**
  - Log communication (call, WhatsApp, email, meeting)
  - Communication history per customer
  - Follow-up reminders dan tasks
  - Communication templates
- **Business Rules:**
  - Mandatory fields: date, type, summary
  - Auto-reminder untuk follow-up
  - Communication linked to specific orders

### 3.2 Inventory Management System

#### 3.2.1 Material Master Data

**REQ-INV-001: Raw Material Management**
- **Description:** System harus dapat mengelola master data raw materials
- **Functional Details:**
  - Material registration (akrilik sheets, accessories, hardware)
  - Material specifications (thickness, color, size, grade)
  - Supplier information per material
  - Material costing dan pricing
- **Business Rules:**
  - Material code format: MAT-CATEGORY-NNNN
  - Multiple suppliers allowed per material
  - Cost history tracking for price analysis
- **Acceptance Criteria:**
  - User dapat add/edit material master data
  - Material dapat di-link ke multiple suppliers
  - Material specifications stored accurately

**REQ-INV-002: Stock Management**
- **Description:** System harus dapat mengelola stock levels dan movements
- **Functional Details:**
  - Current stock levels per material
  - Stock movement tracking (in, out, adjustment)
  - Location-based inventory (warehouse sections)
  - Stock valuation (FIFO method)
- **Business Rules:**
  - Negative stock tidak diperbolehkan
  - Stock movements harus ada approval
  - Monthly stock reconciliation required
- **Acceptance Criteria:**
  - Real-time stock level visibility
  - Stock movement history accessible
  - Stock alerts untuk reorder points

#### 3.2.2 Procurement Management

**REQ-INV-003: Purchase Order Management**
- **Description:** System harus dapat mengelola purchase orders ke suppliers
- **Functional Details:**
  - PO creation berdasarkan reorder points
  - PO approval workflow
  - PO tracking dan receiving
  - Supplier performance monitoring
- **Business Rules:**
  - PO approval required > Rp 2,000,000
  - Lead time tracking per supplier
  - Quality inspection required untuk certain materials
- **Acceptance Criteria:**
  - Automatic PO generation untuk critical stock
  - PO approval workflow berfungsi correctly
  - Receiving process updates stock levels

#### 3.2.3 Inventory Analytics

**REQ-INV-004: Stock Analytics & Reporting**
- **Description:** System harus dapat menyediakan analytics untuk inventory optimization
- **Functional Details:**
  - Stock turnover analysis
  - ABC analysis untuk material classification
  - Slow-moving stock identification
  - Stock level optimization recommendations
- **Business Rules:**
  - Monthly inventory reports mandatory
  - Stock aging analysis untuk quality control
  - Reorder point calculation berdasarkan usage pattern

### 3.3 Production Planning System

#### 3.3.1 Work Order Management

**REQ-PROD-001: Work Order Creation**
- **Description:** System harus dapat membuat work orders dari confirmed sales orders
- **Functional Details:**
  - Automatic work order generation dari sales order
  - Material requirement calculation
  - Production routing dan operations
  - Work order scheduling berdasarkan capacity
- **Business Rules:**
  - Work order numbering: WO-YYYY-MM-NNNN
  - Material availability check sebelum release
  - Work order priority berdasarkan delivery date
- **Acceptance Criteria:**
  - Work order auto-generated dari sales order
  - Material requirements calculated accurately
  - Production schedule optimized untuk delivery dates

**REQ-PROD-002: Production Scheduling**
- **Description:** System harus dapat schedule production activities
- **Functional Details:**
  - Capacity planning berdasarkan resources available
  - Machine dan worker assignment
  - Production timeline dengan dependencies
  - Schedule optimization untuk efficiency
- **Business Rules:**
  - Working hours: 08:00-17:00, Monday-Saturday
  - Overtime calculation untuk urgent orders
  - Machine maintenance windows blocked
- **Acceptance Criteria:**
  - Production schedule visible untuk all stakeholders
  - Resource conflicts identified dan resolved
  - Schedule adjustments dapat dilakukan easily

#### 3.3.2 Production Execution

**REQ-PROD-003: Production Tracking**
- **Description:** System harus dapat track progress production real-time
- **Functional Details:**
  - Operation completion tracking
  - Quality checkpoints monitoring
  - Actual vs planned time recording
  - Production issue logging
- **Business Rules:**
  - Each operation must be completed before next
  - Quality approval required untuk proceed
  - Actual time recording mandatory
- **Acceptance Criteria:**
  - Production progress visible real-time
  - Quality checkpoints enforced
  - Production delays tracked dengan reasons

#### 3.3.3 Quality Control

**REQ-PROD-004: Quality Management**
- **Description:** System harus dapat mengelola quality control processes
- **Functional Details:**
  - Quality inspection checklists
  - Defect tracking dan root cause analysis
  - Quality metrics monitoring
  - Rework management
- **Business Rules:**
  - Quality inspection mandatory untuk all products
  - Rework approval required dari supervisor
  - Quality metrics tracked monthly

### 3.4 Sales & Analytics Dashboard

#### 3.4.1 Sales Performance Monitoring

**REQ-SALES-001: Sales Dashboard**
- **Description:** System harus dapat menampilkan real-time sales performance
- **Functional Details:**
  - Daily, weekly, monthly sales figures
  - Sales by product category
  - Sales by customer segment
  - Comparison dengan targets dan previous periods
- **Business Rules:**
  - Dashboard updated real-time
  - Historical data retained untuk analysis
  - Export functionality untuk reports
- **Acceptance Criteria:**
  - Sales data displayed accurately
  - Dashboard responsive dan fast loading
  - Export functions work correctly

**REQ-SALES-002: Customer Analytics**
- **Description:** System harus dapat menganalisis customer behavior dan profitability
- **Functional Details:**
  - Customer lifetime value calculation
  - Purchase pattern analysis
  - Customer profitability ranking
  - Customer segmentation berdasarkan behavior
- **Business Rules:**
  - Customer data privacy compliance
  - Analytics updated monthly
  - Segmentation criteria configurable

#### 3.4.2 Business Intelligence

**REQ-BI-001: Executive Dashboard**
- **Description:** System harus dapat menyediakan executive-level business insights
- **Functional Details:**
  - Key performance indicators (KPIs)
  - Trend analysis dan forecasting
  - Exception reporting untuk critical issues
  - Drill-down capability untuk detailed analysis
- **Business Rules:**
  - Dashboard accessible untuk authorized users only
  - Data refresh frequency configurable
  - Alert system untuk critical metrics
- **Acceptance Criteria:**
  - Executive dashboard provides clear business insights
  - Alerts triggered correctly untuk exceptions
  - Drill-down functionality works smoothly

---

## 4. NON-FUNCTIONAL REQUIREMENTS

### 4.1 Performance Requirements

| Requirement | Specification |
|-------------|---------------|
| **Response Time** | < 3 seconds untuk semua user interactions |
| **Throughput** | Support 50 concurrent users |
| **Database Performance** | Query response < 2 seconds untuk complex reports |
| **File Upload** | Support file upload up to 10MB |

### 4.2 Security Requirements

| Area | Requirement |
|------|-------------|
| **Authentication** | User login dengan username/password |
| **Authorization** | Role-based access control (RBAC) |
| **Data Encryption** | HTTPS untuk all communications |
| **Audit Trail** | Log all critical data changes |
| **Session Management** | Auto logout setelah 30 menit inactive |

### 4.3 Usability Requirements

| Requirement | Specification |
|-------------|---------------|
| **User Interface** | Responsive design untuk desktop dan tablet |
| **Navigation** | Intuitive menu structure dengan breadcrumbs |
| **Error Handling** | Clear error messages dengan guidance |
| **Help System** | Context-sensitive help dan user guides |

### 4.4 Reliability Requirements

| Requirement | Specification |
|-------------|---------------|
| **System Availability** | 99.5% uptime during business hours |
| **Backup & Recovery** | Daily automated backups dengan recovery procedures |
| **Error Recovery** | Graceful error handling dengan user notification |
| **Data Integrity** | Transaction consistency dengan rollback capability |

---

## 5. USE CASE SCENARIOS

### 5.1 Primary Use Cases

#### Use Case 1: Process Customer Order

**Actors:** Sales Staff, Production Manager, Warehouse Staff  
**Preconditions:** Customer information available, product specifications confirmed  
**Main Flow:**
1. Sales staff receives customer inquiry
2. System creates customer profile (if new)
3. Sales staff creates quotation dengan product specifications
4. Customer approves quotation
5. System converts quotation to sales order
6. Production manager reviews material requirements
7. System checks inventory availability
8. System creates work order untuk production
9. Production team executes work order
10. Quality team approves finished product
11. Warehouse staff updates delivery status
12. Customer receives product dan confirms satisfaction

**Alternative Flows:**
- If material not available: trigger purchase order
- If customer rejects quotation: modify quotation atau close
- If production issues occur: update delivery timeline

**Post-conditions:** Order completed, inventory updated, customer satisfied

#### Use Case 2: Manage Inventory Reorder

**Actors:** Warehouse Manager, Procurement Staff, Supplier  
**Preconditions:** Reorder points configured, supplier information available  
**Main Flow:**
1. System monitors stock levels continuously
2. System detects stock below reorder point
3. System generates reorder alert
4. Warehouse manager reviews inventory status
5. System suggests purchase order based pada usage pattern
6. Procurement staff creates dan approves PO
7. PO sent to supplier
8. Supplier confirms delivery schedule
9. Warehouse staff receives materials
10. System updates inventory levels
11. Quality team inspects materials
12. Materials available untuk production

**Alternative Flows:**
- If supplier cannot fulfill: contact alternative supplier
- If quality issues found: initiate return process
- If urgent requirement: expedite delivery

**Post-conditions:** Inventory replenished, production can continue

---

## 6. DATA REQUIREMENTS

### 6.1 Data Entities

#### Customer Data
- **Customer ID** (Primary Key)
- Personal/Company Information (Name, Address, Phone, Email)
- Business Type dan Industry
- Credit Limit dan Payment Terms
- Customer Category dan Segmentation
- Registration Date dan Status

#### Product Data
- **Product ID** (Primary Key)
- Product Name dan Description
- Product Category dan Subcategory
- Specifications (Material, Size, Color, etc.)
- Standard Cost dan Selling Price
- Lead Time dan Minimum Order Quantity

#### Order Data
- **Order ID** (Primary Key)
- Customer ID (Foreign Key)
- Order Date dan Required Date
- Order Status dan Priority
- Order Items dengan quantities dan pricing
- Total Amount dan Payment Terms
- Delivery Information

#### Inventory Data
- **Material ID** (Primary Key)
- Material Description dan Specifications
- Current Stock Quantity
- Reorder Point dan Maximum Stock
- Unit Cost dan Last Purchase Date
- Supplier Information
- Location dalam warehouse

### 6.2 Data Volume Estimates

| Entity | Current Volume | Growth Rate | 3-Year Projection |
|--------|----------------|-------------|-------------------|
| Customers | 200 | 15% annually | 300+ |
| Products | 50 | 10% annually | 65+ |
| Orders | 1,200/year | 20% annually | 2,000+/year |
| Inventory Items | 100 | 5% annually | 115+ |

### 6.3 Data Quality Requirements

| Aspect | Requirement |
|--------|-------------|
| **Accuracy** | 99.5% data accuracy untuk critical fields |
| **Completeness** | Mandatory fields must be populated |
| **Consistency** | Data format standardization across modules |
| **Timeliness** | Real-time updates untuk transaction data |
| **Validity** | Data validation rules enforced |

---

## 7. INTEGRATION REQUIREMENTS

### 7.1 Internal System Integration

| Module | Integration Point | Data Exchange |
|--------|-------------------|---------------|
| CRM ↔ Inventory | Order processing | Material requirements, availability |
| Inventory ↔ Production | Work order creation | Material allocation, consumption |
| Production ↔ Sales | Order fulfillment | Production status, delivery dates |
| All Modules ↔ Analytics | Reporting | Consolidated data untuk insights |

### 7.2 External System Integration

| System | Integration Type | Purpose |
|--------|------------------|---------|
| **WhatsApp Business API** | Real-time messaging | Customer communication |
| **Email Server** | SMTP integration | Automated notifications |
| **Accounting System** | Data export | Financial reporting |
| **Backup Service** | Automated backup | Data protection |

### 7.3 Data Migration Requirements

| Source | Target | Migration Strategy |
|--------|--------|--------------------|
| Excel Customer Lists | CRM Database | One-time bulk import dengan validation |
| Manual Inventory Records | Inventory Database | Physical verification + data entry |
| Historical Orders | Order Database | Selective migration untuk active orders |

---

## 8. USER STORIES

### 8.1 CRM User Stories

**As a Sales Staff, I want to:**
- Quickly find customer information so that I can provide personalized service
- Track all customer communications so that I have complete interaction history
- Create professional quotations so that I can present proposals effectively
- Monitor order status so that I can keep customers informed

**As a Customer Service Rep, I want to:**
- Access customer order history so that I can resolve inquiries quickly
- Log customer complaints so that issues can be tracked dan resolved
- Send order status updates so that customers stay informed
- Generate customer reports so that I can analyze service quality

### 8.2 Inventory User Stories

**As a Warehouse Manager, I want to:**
- Monitor stock levels in real-time so that I can prevent stockouts
- Receive automatic reorder alerts so that I can maintain optimal inventory
- Track material movements so that I can ensure inventory accuracy
- Generate inventory reports so that I can analyze stock performance

**As a Production Planner, I want to:**
- Check material availability so that I can plan production accurately
- Reserve materials untuk work orders so that production can proceed smoothly
- Track material consumption so that I can update inventory accurately
- Identify material shortages so that I can adjust production plans

### 8.3 Production User Stories

**As a Production Manager, I want to:**
- Schedule work orders efficiently so that delivery commitments are met
- Monitor production progress so that I can identify dan resolve bottlenecks
- Track quality metrics so that I can maintain product standards
- Allocate resources optimally so that productivity is maximized

**As a Production Worker, I want to:**
- Access work order instructions so that I can execute tasks correctly
- Record production progress so that status is updated accurately
- Report quality issues so that problems can be addressed quickly
- Submit completed work so that orders can proceed to next stage

### 8.4 Analytics User Stories

**As a Business Owner, I want to:**
- Monitor key performance indicators so that I can track business health
- Analyze sales trends so that I can make informed decisions
- Identify profitable customers so that I can focus marketing efforts
- Track operational efficiency so that I can improve processes

**As a Sales Manager, I want to:**
- Analyze sales performance so that I can evaluate team effectiveness
- Identify sales opportunities so that I can grow revenue
- Monitor customer satisfaction so that I can improve service quality
- Track market trends so that I can adjust strategies

---

## 9. ACCEPTANCE CRITERIA

### 9.1 System-Level Acceptance Criteria

#### Performance Criteria
- ✅ System response time < 3 seconds untuk 95% of operations
- ✅ System availability 99.5% during business hours (8AM-6PM)
- ✅ Support 50 concurrent users without performance degradation
- ✅ Database backup completed successfully daily

#### Functional Criteria
- ✅ All customer data can be entered, modified, dan retrieved accurately
- ✅ Order processing workflow functions correctly dari quotation to delivery
- ✅ Inventory levels updated real-time dengan all transactions
- ✅ Production scheduling optimizes resource utilization
- ✅ Analytics dashboard displays accurate business metrics

#### Usability Criteria
- ✅ New users can complete basic tasks setelah 2 hours training
- ✅ Error messages provide clear guidance untuk resolution
- ✅ System navigation is intuitive dengan minimal clicks
- ✅ Reports can be generated dan exported easily

#### Security Criteria
- ✅ User authentication works correctly dengan role-based access
- ✅ All critical data changes are logged untuk audit purposes
- ✅ System sessions timeout setelah 30 minutes of inactivity
- ✅ Data encryption implemented untuk sensitive information

### 9.2 Module-Specific Acceptance Criteria

#### CRM Module
- ✅ Customer profiles created dengan all mandatory fields
- ✅ Quotations generated accurately dengan pricing calculations
- ✅ Order status tracked throughout entire lifecycle
- ✅ Communication history maintained untuk each customer

#### Inventory Module
- ✅ Stock levels reflect actual physical inventory
- ✅ Reorder alerts triggered when stock falls below minimum
- ✅ Purchase orders generated dan tracked accurately
- ✅ Material movements recorded dengan proper authorization

#### Production Module
- ✅ Work orders created automatically dari sales orders
- ✅ Production schedules optimized untuk delivery dates
- ✅ Resource allocation prevents conflicts dan overallocation
- ✅ Quality checkpoints enforced throughout production

#### Analytics Module
- ✅ Dashboard displays real-time business metrics
- ✅ Reports generated accurately dengan historical data
- ✅ Trend analysis provides meaningful business insights
- ✅ Export functionality works untuk all report types

---

## 10. ASSUMPTIONS & CONSTRAINTS

### 10.1 Assumptions

#### Business Assumptions
- SATRIAMART will continue current business model dengan growth plans
- Staff will be available untuk training dan system adoption
- Current business processes can be improved through automation
- Data migration dari existing systems akan be accurate

#### Technical Assumptions
- Internet connectivity available at SATRIAMART location
- Hardware infrastructure adequate untuk system requirements
- Third-party services (email, backup) akan be reliable
- Development tools dan technologies akan remain stable

#### User Assumptions
- Users have basic computer literacy
- Users akan embrace new system setelah proper training
- Management support akan continue throughout implementation
- Feedback dari users akan be provided during testing phase

### 10.2 Constraints

#### Budget Constraints
- Total project budget limited to Rp 50,000,000
- No additional hardware purchases beyond basic requirements
- Limited budget untuk third-party tools dan services
- Cost optimization required untuk ongoing maintenance

#### Time Constraints
- Project must be completed dalam 7 weeks
- Limited availability of business users untuk requirements gathering
- Testing period restricted due to business operations
- Go-live date must align dengan business calendar

#### Technical Constraints
- Must work dengan existing hardware infrastructure
- Limited to specific technology stack (React, Node.js, MySQL)
- No integration dengan legacy systems beyond data migration
- Security must comply dengan basic business requirements

#### Resource Constraints
- Limited development team size (5-6 people)
- Part-time availability of business subject matter experts
- Limited testing resources dan environments
- Training must be conducted during business hours

---

## 11. GLOSSARY

| Term | Definition |
|------|------------|
| **BRD** | Business Requirements Document - formal document describing business requirements |
| **CRM** | Customer Relationship Management - strategy untuk managing customer interactions |
| **ERP** | Enterprise Resource Planning - integrated business process management software |
| **KPI** | Key Performance Indicator - measurable value demonstrating business effectiveness |
| **RBAC** | Role-Based Access Control - security approach restricting access based pada user roles |
| **SLA** | Service Level Agreement - commitment between service provider dan customer |
| **UAT** | User Acceptance Testing - testing performed by end users to validate system |
| **Work Order** | Document authorizing dan describing work to be performed |
| **Lead Time** | Time between order initiation dan delivery |
| **Reorder Point** | Inventory level triggering replenishment order |

---

## 12. APPROVAL

| Role | Name | Signature | Date |
|------|------|-----------|------|
| **Business Sponsor** | [SATRIAMART Owner] | ________________ | _______ |
| **Project Manager** | [Nama Mahasiswa] | ________________ | _______ |
| **Technical Lead** | [Development Team Lead] | ________________ | _______ |
| **Business Analyst** | [Requirements Analyst] | ________________ | _______ |
| **Quality Assurance** | [QA Lead] | ________________ | _______ |

---

**Document Control:**
- **Version:** 1.0
- **Date Created:** [Current Date]
- **Created By:** [Nama Mahasiswa]
- **Reviewed By:** [Dosen Pengampu]
- **Next Review:** [Weekly Updates]
- **Status:** [Draft/Approved/Final]
