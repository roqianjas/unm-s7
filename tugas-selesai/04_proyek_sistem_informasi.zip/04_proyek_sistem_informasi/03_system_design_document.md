# SYSTEM DESIGN DOCUMENT (SDD)
## SATRIAMART Integrated Management System (SIMS)

**Universitas Nusa Mandiri**  
**Mata Kuliah: Proyek Sistem Informasi II**  
**Dosen: Rani Irma Handayani, M.Kom**

---

## 1. SYSTEM ARCHITECTURE OVERVIEW

### 1.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                       │
├─────────────────────────────────────────────────────────────┤
│  Web Browser (React.js SPA) │ Mobile-Responsive Interface   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   APPLICATION LAYER                         │
├─────────────────────────────────────────────────────────────┤
│           API Gateway & Load Balancer (Nginx)              │
├─────────────────────────────────────────────────────────────┤
│                  Business Logic Layer                       │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐│
│  │ CRM Service │ │ Inventory   │ │ Production  │ │Analytics││
│  │             │ │ Service     │ │ Service     │ │ Service ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘│
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     DATA LAYER                              │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐│
│  │   MySQL     │ │    Redis    │ │File Storage │ │ Backup  ││
│  │ Primary DB  │ │    Cache    │ │   (Local)   │ │ Service ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘│
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Architecture Principles

#### 1.2.1 Design Principles
- **Modular Design:** Sistem dibagi menjadi 4 module independent
- **Service-Oriented:** Each module sebagai separate service
- **Scalability:** Horizontal scaling capability untuk future growth
- **Security-First:** Security integrated di setiap layer
- **Performance:** Optimized untuk fast response time

#### 1.2.2 Technology Stack

| Layer | Technology | Justification |
|-------|------------|---------------|
| **Frontend** | React.js 18.x | Modern, component-based, excellent ecosystem |
| **Backend** | Node.js + Express.js | JavaScript end-to-end, fast development |
| **Database** | MySQL 8.0 | ACID compliance, proven reliability |
| **Caching** | Redis | High-performance caching layer |
| **Web Server** | Nginx | Load balancing, static file serving |
| **Authentication** | JWT + bcrypt | Stateless, secure token-based auth |

### 1.3 System Context Diagram

```
                    ┌─────────────┐
                    │   Sales     │
                    │   Staff     │
                    └──────┬──────┘
                           │
    ┌─────────────┐        │        ┌─────────────┐
    │ Production  │        │        │ Warehouse   │
    │  Manager    │        │        │  Manager    │
    └──────┬──────┘        │        └──────┬──────┘
           │               │               │
           │               ▼               │
           │    ┌─────────────────────────┐│
           └────┤    SATRIAMART SIMS     ├┘
                │ Integrated Management  │
                │       System          │
                └─────────────────────────┘
                           │
                           ▼
                ┌─────────────────────────┐
                │   External Systems     │
                ├─────────────────────────┤
                │ • WhatsApp Business    │
                │ • Email Server         │
                │ • Backup Service       │
                │ • File Storage         │
                └─────────────────────────┘
```

---

## 2. DETAILED SYSTEM DESIGN

### 2.1 Frontend Architecture

#### 2.1.1 React.js Application Structure

```
src/
├── components/           # Reusable UI components
│   ├── common/          # Common components (buttons, modals, etc.)
│   ├── forms/           # Form components
│   ├── charts/          # Chart components untuk analytics
│   └── layout/          # Layout components (header, sidebar, etc.)
├── pages/               # Page components
│   ├── crm/            # CRM module pages
│   ├── inventory/      # Inventory module pages
│   ├── production/     # Production module pages
│   └── analytics/      # Analytics dashboard pages
├── services/           # API service calls
├── hooks/              # Custom React hooks
├── utils/              # Utility functions
├── store/              # State management (Redux/Zustand)
└── styles/             # CSS/SCSS files
```

#### 2.1.2 State Management

**Technology:** Redux Toolkit untuk complex state, React Context untuk simple state

**State Structure:**
```javascript
{
  auth: {
    user: {},
    token: "",
    isAuthenticated: boolean
  },
  crm: {
    customers: [],
    orders: [],
    quotations: []
  },
  inventory: {
    materials: [],
    stockLevels: [],
    purchaseOrders: []
  },
  production: {
    workOrders: [],
    schedules: [],
    resources: []
  },
  analytics: {
    dashboardData: {},
    reports: []
  }
}
```

#### 2.1.3 UI/UX Design Specifications

**Design System:**
- **Framework:** Material-UI (MUI) atau Ant Design
- **Color Scheme:** 
  - Primary: #1976d2 (Blue)
  - Secondary: #dc004e (Pink)
  - Success: #2e7d32 (Green)
  - Warning: #ed6c02 (Orange)
  - Error: #d32f2f (Red)

**Responsive Breakpoints:**
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

**Navigation Structure:**
```
Main Navigation
├── Dashboard (Analytics overview)
├── CRM
│   ├── Customers
│   ├── Orders
│   ├── Quotations
│   └── Communications
├── Inventory
│   ├── Stock Management
│   ├── Purchase Orders
│   ├── Suppliers
│   └── Reports
├── Production
│   ├── Work Orders
│   ├── Scheduling
│   ├── Resources
│   └── Quality Control
└── Settings
    ├── User Management
    ├── System Configuration
    └── Audit Logs
```

### 2.2 Backend Architecture

#### 2.2.1 Microservices Design

**Service Decomposition:**

```
API Gateway (Express.js)
├── Authentication Service
├── CRM Service
│   ├── Customer Management
│   ├── Order Management
│   └── Communication Tracking
├── Inventory Service
│   ├── Stock Management
│   ├── Procurement
│   └── Supplier Management
├── Production Service
│   ├── Work Order Management
│   ├── Scheduling
│   └── Quality Control
└── Analytics Service
    ├── Data Aggregation
    ├── Report Generation
    └── Dashboard APIs
```

#### 2.2.2 API Design Patterns

**RESTful API Design:**

```
Base URL: https://api.satriamart.com/v1

Authentication:
POST /auth/login
POST /auth/logout
GET  /auth/me

CRM APIs:
GET    /customers              # List customers
POST   /customers              # Create customer
GET    /customers/:id          # Get customer details
PUT    /customers/:id          # Update customer
DELETE /customers/:id          # Delete customer

GET    /orders                 # List orders
POST   /orders                 # Create order
GET    /orders/:id             # Get order details
PUT    /orders/:id/status      # Update order status

Inventory APIs:
GET    /inventory/materials    # List materials
POST   /inventory/materials    # Add material
GET    /inventory/stock        # Current stock levels
POST   /inventory/movements    # Record stock movement

Production APIs:
GET    /production/workorders  # List work orders
POST   /production/workorders  # Create work order
GET    /production/schedule    # Production schedule
PUT    /production/workorders/:id/progress  # Update progress

Analytics APIs:
GET    /analytics/dashboard    # Dashboard data
GET    /analytics/reports/:type # Generate reports
```

#### 2.2.3 Service Layer Architecture

**Each Service Structure:**
```
service/
├── controllers/        # HTTP request handlers
├── services/          # Business logic
├── models/            # Data models (Sequelize ORM)
├── middleware/        # Custom middleware
├── utils/             # Utility functions
├── validation/        # Input validation schemas
└── tests/             # Unit dan integration tests
```

**Example Controller Pattern:**
```javascript
// controllers/customerController.js
class CustomerController {
  async getCustomers(req, res) {
    try {
      const customers = await customerService.findAll(req.query);
      res.json({
        success: true,
        data: customers,
        pagination: req.pagination
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: error.message
      });
    }
  }
}
```

### 2.3 Database Design

#### 2.3.1 Entity Relationship Diagram (ERD)

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│    CUSTOMERS    │    │     ORDERS      │    │   ORDER_ITEMS   │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ customer_id (PK)│───┐│ order_id (PK)   │───┐│ order_item_id   │
│ name            │   └┤ customer_id (FK)│   └┤ order_id (FK)   │
│ email           │    │ order_date      │    │ product_id (FK) │
│ phone           │    │ status          │    │ quantity        │
│ address         │    │ total_amount    │    │ unit_price      │
│ customer_type   │    │ delivery_date   │    │ total_price     │
│ created_at      │    └─────────────────┘    └─────────────────┘
└─────────────────┘           │
                              │
┌─────────────────┐           │    ┌─────────────────┐
│    PRODUCTS     │           │    │  WORK_ORDERS    │
├─────────────────┤           │    ├─────────────────┤
│ product_id (PK) │──────────────┬─┤ work_order_id   │
│ product_name    │              │ │ order_id (FK)   │
│ description     │              │ │ status          │
│ category        │              │ │ start_date      │
│ unit_price      │              │ │ due_date        │
│ specifications  │              │ │ priority        │
└─────────────────┘              │ └─────────────────┘
                                 │
┌─────────────────┐              │ ┌─────────────────┐
│   MATERIALS     │              │ │   INVENTORY     │
├─────────────────┤              │ ├─────────────────┤
│ material_id (PK)│─────────────────┤ inventory_id    │
│ material_name   │                │ material_id (FK)│
│ specification   │                │ current_stock   │
│ unit_of_measure │                │ reorder_point   │
│ standard_cost   │                │ maximum_stock   │
│ supplier_id     │                │ last_updated    │
└─────────────────┘                └─────────────────┘
```

#### 2.3.2 Database Schema Design

**Table Definitions:**

```sql
-- Customers Table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    customer_type ENUM('individual', 'business') DEFAULT 'individual',
    credit_limit DECIMAL(15,2) DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_customer_email (email),
    INDEX idx_customer_phone (phone)
);

-- Products Table
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_code VARCHAR(50) UNIQUE NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    subcategory VARCHAR(100),
    unit_price DECIMAL(10,2),
    specifications JSON,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_product_code (product_code),
    INDEX idx_product_category (category)
);

-- Orders Table
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    required_date DATE,
    delivery_date DATE,
    status ENUM('draft', 'confirmed', 'in_production', 'ready', 'delivered', 'cancelled') DEFAULT 'draft',
    subtotal DECIMAL(15,2),
    tax_amount DECIMAL(15,2),
    total_amount DECIMAL(15,2),
    payment_status ENUM('pending', 'partial', 'paid') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    INDEX idx_order_number (order_number),
    INDEX idx_order_status (status),
    INDEX idx_order_date (order_date)
);

-- Order Items Table
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(15,2) NOT NULL,
    specifications JSON,
    notes TEXT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_order_items_order (order_id)
);

-- Materials Table
CREATE TABLE materials (
    material_id INT PRIMARY KEY AUTO_INCREMENT,
    material_code VARCHAR(50) UNIQUE NOT NULL,
    material_name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    unit_of_measure VARCHAR(20),
    standard_cost DECIMAL(10,4),
    specifications JSON,
    supplier_id INT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_material_code (material_code),
    INDEX idx_material_category (category)
);

-- Inventory Table
CREATE TABLE inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    material_id INT NOT NULL,
    current_stock DECIMAL(12,4) DEFAULT 0,
    reserved_stock DECIMAL(12,4) DEFAULT 0,
    available_stock DECIMAL(12,4) GENERATED ALWAYS AS (current_stock - reserved_stock) STORED,
    reorder_point DECIMAL(12,4) DEFAULT 0,
    maximum_stock DECIMAL(12,4),
    last_movement_date TIMESTAMP,
    last_count_date DATE,
    location VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (material_id) REFERENCES materials(material_id),
    UNIQUE KEY uk_inventory_material (material_id),
    INDEX idx_inventory_reorder (reorder_point, available_stock)
);

-- Work Orders Table
CREATE TABLE work_orders (
    work_order_id INT PRIMARY KEY AUTO_INCREMENT,
    work_order_number VARCHAR(50) UNIQUE NOT NULL,
    order_id INT NOT NULL,
    status ENUM('planned', 'released', 'in_progress', 'completed', 'cancelled') DEFAULT 'planned',
    priority ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
    planned_start_date DATE,
    planned_end_date DATE,
    actual_start_date DATE,
    actual_end_date DATE,
    assigned_to VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    INDEX idx_work_order_number (work_order_number),
    INDEX idx_work_order_status (status),
    INDEX idx_work_order_dates (planned_start_date, planned_end_date)
);
```

#### 2.3.3 Database Optimization

**Indexing Strategy:**
- Primary keys untuk all tables
- Foreign key indexes untuk join performance
- Composite indexes untuk common query patterns
- Covering indexes untuk frequently accessed columns

**Performance Optimizations:**
- Query optimization dengan EXPLAIN plans
- Connection pooling (max 50 connections)
- Read replicas untuk reporting queries
- Partitioning untuk large historical data

### 2.4 Security Design

#### 2.4.1 Authentication & Authorization

**Authentication Flow:**
```
1. User login dengan credentials
2. Server validates credentials
3. Server generates JWT token
4. Client stores token dalam secure storage
5. Client sends token dalam Authorization header
6. Server validates token untuk each request
```

**JWT Token Structure:**
```javascript
{
  "header": {
    "alg": "HS256",
    "typ": "JWT"
  },
  "payload": {
    "userId": 123,
    "email": "user@satriamart.com",
    "role": "sales_staff",
    "permissions": ["read_customers", "write_orders"],
    "iat": 1635724800,
    "exp": 1635811200
  }
}
```

**Role-Based Access Control (RBAC):**

| Role | Permissions |
|------|-------------|
| **Admin** | Full system access, user management |
| **Manager** | Read/write access semua modules, reporting |
| **Sales Staff** | CRM full access, inventory read, production read |
| **Production Staff** | Production full access, inventory read |
| **Warehouse Staff** | Inventory full access, production read |

#### 2.4.2 Data Security

**Encryption:**
- HTTPS untuk all communications (TLS 1.3)
- Password hashing dengan bcrypt (salt rounds: 12)
- Sensitive data encrypted at rest
- JWT tokens dengan secure signing key

**Input Validation:**
- SQL injection prevention dengan parameterized queries
- XSS prevention dengan input sanitization
- CSRF protection dengan tokens
- File upload validation dan scanning

**Audit Trail:**
```sql
CREATE TABLE audit_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100),
    table_name VARCHAR(100),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_table (table_name, record_id),
    INDEX idx_audit_date (created_at)
);
```

### 2.5 Integration Design

#### 2.5.1 Internal Module Integration

**Event-Driven Architecture:**
```javascript
// Event Publisher (Order Service)
eventBus.publish('order.confirmed', {
  orderId: 123,
  customerId: 456,
  items: [...],
  requiredDate: '2024-01-15'
});

// Event Subscribers
// Inventory Service
eventBus.subscribe('order.confirmed', (orderData) => {
  // Reserve materials untuk production
  inventoryService.reserveMaterials(orderData);
});

// Production Service
eventBus.subscribe('order.confirmed', (orderData) => {
  // Create work order
  productionService.createWorkOrder(orderData);
});
```

#### 2.5.2 External System Integration

**WhatsApp Business API Integration:**
```javascript
// WhatsApp Service
class WhatsAppService {
  async sendOrderUpdate(customer, order) {
    const message = `
      Halo ${customer.name},
      Status order #${order.orderNumber} telah berubah menjadi: ${order.status}
      Estimasi selesai: ${order.estimatedDate}
      
      Terima kasih!
      SATRIAMART Team
    `;
    
    await whatsappClient.sendMessage(customer.phone, message);
  }
}
```

**Email Service Integration:**
```javascript
// Email Service
class EmailService {
  async sendQuotation(customer, quotation) {
    const emailContent = await templateEngine.render('quotation', {
      customer,
      quotation,
      company: companyInfo
    });
    
    await emailClient.sendMail({
      to: customer.email,
      subject: `Quotation #${quotation.number} - SATRIAMART`,
      html: emailContent,
      attachments: [quotation.pdfFile]
    });
  }
}
```

---

## 3. PERFORMANCE DESIGN

### 3.1 Performance Requirements

| Metric | Target | Measurement |
|--------|--------|-------------|
| **Page Load Time** | < 3 seconds | 95th percentile |
| **API Response Time** | < 500ms | Average response |
| **Database Query Time** | < 100ms | Complex queries |
| **Concurrent Users** | 50 users | Without degradation |
| **System Availability** | 99.5% | Monthly uptime |

### 3.2 Performance Optimization Strategies

#### 3.2.1 Frontend Optimization

**Code Splitting:**
```javascript
// Lazy loading modules
const CRMModule = lazy(() => import('./pages/crm'));
const InventoryModule = lazy(() => import('./pages/inventory'));
const ProductionModule = lazy(() => import('./pages/production'));

// Route-based code splitting
<Route path="/crm" component={CRMModule} />
<Route path="/inventory" component={InventoryModule} />
<Route path="/production" component={ProductionModule} />
```

**Caching Strategy:**
- Browser caching untuk static assets (1 year)
- Service Worker untuk offline functionality
- Redux state persistence untuk user preferences
- API response caching (5 minutes TTL)

#### 3.2.2 Backend Optimization

**Database Optimization:**
```sql
-- Query optimization example
SELECT 
    o.order_id,
    o.order_number,
    c.name as customer_name,
    o.total_amount,
    o.status
FROM orders o
INNER JOIN customers c ON o.customer_id = c.customer_id
WHERE o.order_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND o.status IN ('confirmed', 'in_production')
ORDER BY o.order_date DESC
LIMIT 20;

-- Index untuk query optimization
CREATE INDEX idx_orders_date_status ON orders(order_date, status);
```

**Caching Layer (Redis):**
```javascript
// Cache frequently accessed data
class CacheService {
  async getCustomer(customerId) {
    const cacheKey = `customer:${customerId}`;
    let customer = await redis.get(cacheKey);
    
    if (!customer) {
      customer = await database.customers.findById(customerId);
      await redis.setex(cacheKey, 3600, JSON.stringify(customer)); // 1 hour TTL
    }
    
    return JSON.parse(customer);
  }
}
```

### 3.3 Scalability Design

#### 3.3.1 Horizontal Scaling

**Load Balancing Configuration:**
```nginx
# Nginx load balancer configuration
upstream satriamart_api {
    server app1.satriamart.com:3000 weight=3;
    server app2.satriamart.com:3000 weight=2;
    server app3.satriamart.com:3000 weight=1;
}

server {
    listen 80;
    server_name api.satriamart.com;
    
    location / {
        proxy_pass http://satriamart_api;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

#### 3.3.2 Database Scaling

**Read Replicas:**
```javascript
// Database connection strategy
const dbConfig = {
  master: {
    host: 'master.db.satriamart.com',
    database: 'satriamart',
    username: 'app_user',
    password: process.env.DB_PASSWORD
  },
  slave: {
    host: 'slave.db.satriamart.com',
    database: 'satriamart',
    username: 'readonly_user',
    password: process.env.DB_READONLY_PASSWORD
  }
};

// Use master untuk writes, slave untuk reads
const writeDB = new Sequelize(dbConfig.master);
const readDB = new Sequelize(dbConfig.slave);
```

---

## 4. ERROR HANDLING & LOGGING

### 4.1 Error Handling Strategy

#### 4.1.1 HTTP Error Responses

**Standardized Error Format:**
```javascript
{
  "success": false,
  "error": {
    "code": "CUSTOMER_NOT_FOUND",
    "message": "Customer with ID 123 not found",
    "details": {
      "customerId": 123,
      "timestamp": "2024-01-15T10:30:00Z"
    }
  },
  "requestId": "req_abc123def456"
}
```

#### 4.1.2 Error Categories

| HTTP Status | Error Type | Example |
|-------------|------------|---------|
| **400** | Bad Request | Invalid input data |
| **401** | Unauthorized | Invalid authentication token |
| **403** | Forbidden | Insufficient permissions |
| **404** | Not Found | Resource not found |
| **409** | Conflict | Duplicate resource |
| **422** | Validation Error | Business rule validation failed |
| **500** | Internal Error | Unexpected server error |

### 4.2 Logging Strategy

#### 4.2.1 Log Levels

```javascript
// Winston logger configuration
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
    new winston.transports.Console({ format: winston.format.simple() })
  ]
});

// Usage examples
logger.error('Database connection failed', { error: dbError });
logger.warn('High memory usage detected', { memoryUsage: process.memoryUsage() });
logger.info('Order created successfully', { orderId: 123, customerId: 456 });
logger.debug('Query execution time', { query: sqlQuery, duration: 150 });
```

#### 4.2.2 Monitoring & Alerts

**Key Metrics to Monitor:**
- API response times (average, 95th percentile)
- Error rates (4xx, 5xx errors)
- Database connection pool usage
- Memory dan CPU utilization
- Active user sessions

**Alert Thresholds:**
- Error rate > 5% dalam 5 minutes
- Average response time > 1 second
- Database connection pool > 80% utilized
- Memory usage > 90%
- System availability < 99%

---

## 5. DEPLOYMENT DESIGN

### 5.1 Environment Strategy

#### 5.1.1 Environment Configuration

| Environment | Purpose | Configuration |
|-------------|---------|---------------|
| **Development** | Local development | Single server, mock external services |
| **Testing** | QA testing | Staging server, test data |
| **Production** | Live system | Production servers, real data |

#### 5.1.2 Infrastructure Requirements

**Hardware Specifications:**

| Component | Development | Testing | Production |
|-----------|-------------|---------|------------|
| **Web Server** | 2 vCPU, 4GB RAM | 2 vCPU, 8GB RAM | 4 vCPU, 16GB RAM |
| **Database Server** | 2 vCPU, 4GB RAM | 4 vCPU, 8GB RAM | 8 vCPU, 32GB RAM |
| **Storage** | 50GB SSD | 100GB SSD | 500GB SSD |
| **Network** | 100 Mbps | 500 Mbps | 1 Gbps |

### 5.2 Deployment Strategy

#### 5.2.1 CI/CD Pipeline

```yaml
# GitHub Actions workflow
name: SATRIAMART SIMS CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Install dependencies
        run: npm ci
      - name: Run tests
        run: npm run test
      - name: Run linting
        run: npm run lint

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Build application
        run: |
          npm ci
          npm run build
      - name: Build Docker image
        run: docker build -t satriamart-sims:${{ github.sha }} .

  deploy:
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - name: Deploy to production
        run: |
          # Deploy commands
          echo "Deploying to production..."
```

#### 5.2.2 Docker Configuration

**Dockerfile:**
```dockerfile
# Frontend Dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]

# Backend Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["node", "index.js"]
```

**Docker Compose:**
```yaml
version: '3.8'
services:
  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - backend

  backend:
    build: ./backend
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DB_HOST=database
    depends_on:
      - database
      - redis

  database:
    image: mysql:8.0
    environment:
      - MYSQL_ROOT_PASSWORD=${DB_ROOT_PASSWORD}
      - MYSQL_DATABASE=satriamart
    volumes:
      - mysql_data:/var/lib/mysql
    ports:
      - "3306:3306"

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"

volumes:
  mysql_data:
```

---

## 6. TESTING STRATEGY

### 6.1 Testing Pyramid

```
                    ┌─────────────────┐
                    │   E2E Tests     │  ← Few, slow, expensive
                    │   (Cypress)     │
                    └─────────────────┘
                  ┌───────────────────────┐
                  │  Integration Tests    │  ← Some, medium speed
                  │  (Jest + Supertest)   │
                  └───────────────────────┘
              ┌─────────────────────────────────┐
              │        Unit Tests               │  ← Many, fast, cheap
              │  (Jest + React Testing Library) │
              └─────────────────────────────────┘
```

### 6.2 Testing Implementation

#### 6.2.1 Unit Testing

**Frontend Unit Tests:**
```javascript
// CustomerForm.test.js
import { render, fireEvent, waitFor } from '@testing-library/react';
import CustomerForm from './CustomerForm';

describe('CustomerForm', () => {
  test('should validate required fields', async () => {
    const { getByText, getByLabelText } = render(<CustomerForm />);
    
    fireEvent.click(getByText('Save'));
    
    await waitFor(() => {
      expect(getByText('Name is required')).toBeInTheDocument();
      expect(getByText('Phone is required')).toBeInTheDocument();
    });
  });

  test('should submit form dengan valid data', async () => {
    const mockSubmit = jest.fn();
    const { getByLabelText, getByText } = render(
      <CustomerForm onSubmit={mockSubmit} />
    );
    
    fireEvent.change(getByLabelText('Name'), { target: { value: 'John Doe' } });
    fireEvent.change(getByLabelText('Phone'), { target: { value: '081234567890' } });
    fireEvent.click(getByText('Save'));
    
    await waitFor(() => {
      expect(mockSubmit).toHaveBeenCalledWith({
        name: 'John Doe',
        phone: '081234567890'
      });
    });
  });
});
```

**Backend Unit Tests:**
```javascript
// customerService.test.js
const customerService = require('./customerService');
const { Customer } = require('../models');

describe('CustomerService', () => {
  describe('createCustomer', () => {
    test('should create customer dengan valid data', async () => {
      const customerData = {
        name: 'John Doe',
        email: 'john@example.com',
        phone: '081234567890'
      };
      
      const mockCreate = jest.spyOn(Customer, 'create');
      mockCreate.mockResolvedValue({ id: 1, ...customerData });
      
      const result = await customerService.createCustomer(customerData);
      
      expect(mockCreate).toHaveBeenCalledWith(customerData);
      expect(result.id).toBe(1);
      expect(result.name).toBe('John Doe');
    });
  });
});
```

#### 6.2.2 Integration Testing

```javascript
// orderAPI.test.js
const request = require('supertest');
const app = require('../app');

describe('Order API', () => {
  test('POST /api/orders should create new order', async () => {
    const orderData = {
      customerId: 1,
      items: [
        { productId: 1, quantity: 2, unitPrice: 50000 }
      ]
    };
    
    const response = await request(app)
      .post('/api/orders')
      .send(orderData)
      .expect(201);
    
    expect(response.body.success).toBe(true);
    expect(response.body.data.orderId).toBeDefined();
    expect(response.body.data.totalAmount).toBe(100000);
  });
});
```

#### 6.2.3 End-to-End Testing

```javascript
// cypress/integration/order-flow.spec.js
describe('Order Management Flow', () => {
  it('should complete full order process', () => {
    // Login
    cy.visit('/login');
    cy.get('[data-testid=email]').type('sales@satriamart.com');
    cy.get('[data-testid=password]').type('password');
    cy.get('[data-testid=login-button]').click();
    
    // Create customer
    cy.get('[data-testid=customers-menu]').click();
    cy.get('[data-testid=add-customer]').click();
    cy.get('[data-testid=customer-name]').type('Test Customer');
    cy.get('[data-testid=customer-phone]').type('081234567890');
    cy.get('[data-testid=save-customer]').click();
    
    // Create order
    cy.get('[data-testid=orders-menu]').click();
    cy.get('[data-testid=add-order]').click();
    cy.get('[data-testid=select-customer]').select('Test Customer');
    cy.get('[data-testid=add-item]').click();
    cy.get('[data-testid=product-select]').select('Acrylic Display Stand');
    cy.get('[data-testid=quantity]').type('2');
    cy.get('[data-testid=save-order]').click();
    
    // Verify order created
    cy.get('[data-testid=order-list]').should('contain', 'Test Customer');
    cy.get('[data-testid=order-status]').should('contain', 'Draft');
  });
});
```

---

## 7. MAINTENANCE & SUPPORT

### 7.1 System Maintenance

#### 7.1.1 Routine Maintenance Tasks

| Task | Frequency | Description |
|------|-----------|-------------|
| **Database Backup** | Daily | Automated full backup at 2 AM |
| **Log Rotation** | Weekly | Archive old logs, maintain 30 days |
| **Security Updates** | Monthly | Apply security patches |
| **Performance Review** | Monthly | Analyze performance metrics |
| **Disk Cleanup** | Monthly | Remove temporary files |
| **Dependency Updates** | Quarterly | Update libraries dan frameworks |

#### 7.1.2 Monitoring Dashboard

**Key Metrics:**
- System uptime dan availability
- Response time trends
- Error rate patterns
- Database performance
- User activity statistics
- Security events

### 7.2 Support Procedures

#### 7.2.1 Issue Classification

| Priority | Response Time | Description |
|----------|---------------|-------------|
| **Critical** | 1 hour | System down, data loss |
| **High** | 4 hours | Major functionality impacted |
| **Medium** | 1 business day | Minor functionality issues |
| **Low** | 3 business days | Enhancement requests |

#### 7.2.2 Escalation Matrix

```
Level 1: Technical Support
    ↓ (15 minutes)
Level 2: Senior Developer
    ↓ (30 minutes)
Level 3: System Administrator
    ↓ (1 hour)
Level 4: Project Manager
```

---

## 8. CONCLUSION

System Design Document ini menyediakan blueprint komprehensif untuk pengembangan SATRIAMART Integrated Management System. Design ini mempertimbangkan:

1. **Scalability:** Architecture yang dapat grow dengan business
2. **Performance:** Optimized untuk response time dan throughput
3. **Security:** Comprehensive security measures
4. **Maintainability:** Clean code dan proper documentation
5. **User Experience:** Intuitive interface dan workflow

**Key Success Factors:**
- ✅ Modular architecture memungkinkan independent development
- ✅ Technology stack yang proven dan reliable
- ✅ Comprehensive testing strategy ensures quality
- ✅ Performance optimization dari design phase
- ✅ Security built-in dari ground up

**Next Steps:**
1. ✅ Technical review dan approval
2. ✅ Development environment setup
3. ✅ Team onboarding dan technical training
4. ✅ Development phase initiation
5. ✅ Regular design reviews selama development

---

**Document Control:**
- **Version:** 1.0
- **Date Created:** [Current Date]
- **Created By:** [Nama Mahasiswa]
- **Reviewed By:** [Technical Lead]
- **Approved By:** [Dosen Pengampu]
- **Next Review:** [Bi-weekly Reviews]
