# PROJECT CHARTER & PLAN
## SATRIAMART Integrated Management System (SIMS)

**Universitas Nusa Mandiri**  
**Mata Kuliah: Proyek Sistem Informasi II**  
**Dosen: Rani Irma Handayani, M.Kom**

---

## PROJECT CHARTER

### 1. PROJECT OVERVIEW

**Project Name:** SATRIAMART Integrated Management System (SIMS)  
**Project Manager:** [Nama Mahasiswa]  
**Start Date:** [Tanggal Mulai]  
**Expected End Date:** [Tanggal Berakhir - 7 minggu]  
**Project Budget:** Rp 50.000.000 (estimasi development cost)

### 2. BUSINESS CASE

#### Problem Statement
SATRIAMART saat ini menghadapi challenges dalam:
- **Manual Process Management:** Proses order, produksi, dan inventory masih manual
- **Data Fragmentation:** Data customer, produk, dan sales tersebar dalam berbagai file
- **Limited Visibility:** Tidak ada real-time monitoring terhadap business performance
- **Scalability Issues:** Sistem manual tidak dapat mengakomodasi pertumbuhan bisnis

#### Business Justification
Implementasi SIMS akan memberikan benefits:
- **Operational Efficiency:** Otomasi proses bisnis mengurangi manual work 40%
- **Data Integration:** Single source of truth untuk semua business data
- **Real-time Analytics:** Dashboard untuk monitoring KPI secara real-time
- **Scalability:** Foundation untuk pertumbuhan bisnis jangka panjang
- **ROI Estimation:** Break-even dalam 18 bulan dengan peningkatan efisiensi 30%

### 3. PROJECT OBJECTIVES

#### Primary Objectives
1. **Mengembangkan sistem terintegrasi** yang menghubungkan CRM, Inventory, Production, dan Sales
2. **Meningkatkan operational efficiency** melalui otomasi proses bisnis
3. **Menyediakan real-time business intelligence** melalui dashboard analytics
4. **Membangun scalable architecture** yang dapat berkembang sesuai kebutuhan bisnis

#### Success Criteria
- ✅ Sistem dapat handle 100+ orders per bulan
- ✅ Response time sistem < 3 detik untuk semua operasi
- ✅ Data accuracy 99.5% untuk inventory tracking
- ✅ User adoption rate > 80% dalam 1 bulan
- ✅ Training completion rate 100% untuk semua users

### 4. PROJECT SCOPE

#### In Scope
**Core Modules:**
- **Customer Relationship Management (CRM)**
  - Customer registration dan profiling
  - Order tracking dan communication history
  - Customer analytics dan segmentation

- **Inventory Management System**
  - Raw material tracking (akrilik sheets, accessories)
  - Automatic reorder points dan alerts
  - Supplier management dan procurement

- **Production Planning System**
  - Work order management dan scheduling
  - Resource allocation dan capacity planning
  - Quality control tracking

- **Sales & Analytics Dashboard**
  - Sales performance monitoring
  - Revenue analytics dan forecasting
  - Business intelligence reporting

#### Out of Scope
- E-commerce website development
- Mobile application development
- Financial accounting system
- HR management system
- Third-party integrations (payment gateway, shipping)

### 5. STAKEHOLDERS

| Role | Name | Responsibility | Influence |
|------|------|----------------|-----------|
| Project Sponsor | Pemilik SATRIAMART | Final approval, budget allocation | High |
| Business Users | Manager Operations | Requirements definition, testing | High |
| Technical Team | Development Team | System development, testing | Medium |
| End Users | Staff SATRIAMART | System usage, feedback | Medium |
| Project Manager | [Nama Mahasiswa] | Project coordination, delivery | High |

### 6. HIGH-LEVEL TIMELINE

| Phase | Duration | Key Milestones |
|-------|----------|----------------|
| **Phase 1: Planning & Analysis** | Week 1-2 | Requirements approved, Design completed |
| **Phase 2: Development Sprint 1** | Week 3-4 | CRM & Inventory modules completed |
| **Phase 3: Development Sprint 2** | Week 5-6 | Production & Analytics modules completed |
| **Phase 4: Testing & Deployment** | Week 7 | System tested, deployed, users trained |

---

## DETAILED PROJECT PLAN

### 1. WORK BREAKDOWN STRUCTURE (WBS)

#### 1.0 PROJECT MANAGEMENT
- 1.1 Project initiation dan planning
- 1.2 Team coordination dan communication
- 1.3 Progress monitoring dan reporting
- 1.4 Risk management dan issue resolution
- 1.5 Project closure dan documentation

#### 2.0 BUSINESS ANALYSIS
- 2.1 Requirements gathering dan analysis
- 2.2 Business process mapping
- 2.3 Use case development
- 2.4 User story creation
- 2.5 Requirements validation

#### 3.0 SYSTEM DESIGN
- 3.1 System architecture design
- 3.2 Database design dan modeling
- 3.3 User interface design
- 3.4 API design dan specifications
- 3.5 Security design dan protocols

#### 4.0 DEVELOPMENT
- 4.1 Development environment setup
- 4.2 CRM module development
- 4.3 Inventory module development
- 4.4 Production module development
- 4.5 Analytics dashboard development
- 4.6 System integration dan testing

#### 5.0 TESTING
- 5.1 Unit testing
- 5.2 Integration testing
- 5.3 System testing
- 5.4 User acceptance testing
- 5.5 Performance testing

#### 6.0 DEPLOYMENT
- 6.1 Production environment setup
- 6.2 Data migration
- 6.3 System deployment
- 6.4 User training
- 6.5 Go-live support

### 2. DETAILED SCHEDULE

#### Week 1: Project Initiation & Requirements
**Deliverables:**
- Project charter approved
- Stakeholder analysis completed
- Requirements gathering sessions conducted
- Business requirements document (BRD) draft

**Activities:**
- Kickoff meeting dengan stakeholders
- Requirements workshops dengan business users
- Current state analysis
- Preliminary risk assessment

#### Week 2: System Design
**Deliverables:**
- System architecture document
- Database design dan ER diagram
- User interface mockups
- Technical specifications

**Activities:**
- Architecture design sessions
- Database modeling
- UI/UX design workshops
- Technical feasibility assessment

#### Week 3-4: Development Sprint 1
**Deliverables:**
- CRM module (80% complete)
- Inventory module (80% complete)
- Basic user authentication
- Core database structure

**Activities:**
- Development environment setup
- Core functionality development
- Unit testing implementation
- Code review sessions

#### Week 5-6: Development Sprint 2
**Deliverables:**
- Production planning module
- Analytics dashboard
- System integration
- Complete testing suite

**Activities:**
- Advanced features development
- Module integration
- Performance optimization
- Security implementation

#### Week 7: Testing & Deployment
**Deliverables:**
- Fully tested system
- Deployed production system
- User training materials
- Go-live documentation

**Activities:**
- Comprehensive testing
- User acceptance testing
- Production deployment
- User training sessions

### 3. RESOURCE ALLOCATION

#### Human Resources
| Role | Allocation | Key Responsibilities |
|------|------------|---------------------|
| Project Manager | 100% (7 weeks) | Overall project coordination |
| Business Analyst | 60% (2 weeks) | Requirements dan process analysis |
| System Architect | 40% (2 weeks) | Technical architecture design |
| Frontend Developer | 80% (4 weeks) | UI development |
| Backend Developer | 80% (4 weeks) | API dan business logic |
| Database Developer | 60% (3 weeks) | Database design dan optimization |
| QA Tester | 60% (3 weeks) | Testing dan quality assurance |

#### Technology Resources
- **Development Environment:** AWS EC2 instances
- **Database:** MySQL 8.0 untuk production data
- **Frontend:** React.js dengan modern UI framework
- **Backend:** Node.js/Express untuk API development
- **Tools:** Git, Docker, Jenkins untuk CI/CD

### 4. BUDGET BREAKDOWN

| Category | Cost (IDR) | Percentage |
|----------|------------|------------|
| **Development Resources** | 35,000,000 | 70% |
| **Infrastructure & Tools** | 8,000,000 | 16% |
| **Testing & QA** | 4,000,000 | 8% |
| **Training & Documentation** | 2,000,000 | 4% |
| **Contingency (10%)** | 1,000,000 | 2% |
| **TOTAL** | **50,000,000** | **100%** |

### 5. RISK REGISTER

| Risk | Impact | Probability | Mitigation Strategy |
|------|--------|-------------|-------------------|
| **Scope Creep** | High | Medium | Clear requirements documentation, change control process |
| **Technical Complexity** | High | Medium | Proof of concept, expert consultation |
| **Resource Availability** | Medium | Low | Cross-training, backup resources |
| **User Adoption** | Medium | Medium | Early user involvement, comprehensive training |
| **Data Migration Issues** | High | Low | Thorough data analysis, migration testing |
| **Performance Issues** | Medium | Medium | Performance testing, optimization planning |

### 6. COMMUNICATION PLAN

#### Stakeholder Communication Matrix
| Stakeholder | Frequency | Method | Content |
|-------------|-----------|--------|---------|
| Project Sponsor | Weekly | Email report | High-level status, budget, risks |
| Business Users | Bi-weekly | Meetings | Progress demo, feedback sessions |
| Technical Team | Daily | Standup meetings | Technical progress, blockers |
| End Users | Monthly | Workshops | Training, feedback collection |

#### Reporting Schedule
- **Daily:** Team standup meetings (15 mins)
- **Weekly:** Stakeholder status reports
- **Bi-weekly:** Steering committee meetings
- **Monthly:** Executive dashboard updates

---

## PROJECT GOVERNANCE

### 1. PROJECT ORGANIZATION

```
Project Sponsor (SATRIAMART Owner)
        |
Project Manager (Mahasiswa)
        |
    ┌───────┴───────┐
Business Team    Technical Team
    |                |
Requirements     Development
Testing          Infrastructure
Training         Support
```

### 2. DECISION MAKING AUTHORITY

| Decision Type | Authority Level | Approval Required |
|---------------|----------------|-------------------|
| Scope Changes | Project Sponsor | Steering Committee |
| Technical Decisions | Technical Lead | Project Manager |
| Resource Allocation | Project Manager | Project Sponsor |
| Budget Variance | Project Sponsor | Steering Committee |

### 3. QUALITY STANDARDS

#### Development Standards
- **Code Quality:** Minimum 80% test coverage
- **Documentation:** All APIs documented dengan Swagger
- **Security:** OWASP security guidelines compliance
- **Performance:** Page load time < 3 seconds

#### Deliverable Standards
- **Requirements:** Must be testable dan measurable
- **Design:** Must follow UI/UX best practices
- **Code:** Must pass code review dan automated testing
- **Documentation:** Must be complete dan up-to-date

---

## SUCCESS METRICS & KPIs

### 1. PROJECT SUCCESS METRICS

| Metric | Target | Measurement Method |
|--------|--------|--------------------|
| **Schedule Performance** | On-time delivery | Milestone completion dates |
| **Budget Performance** | Within 10% of budget | Actual vs planned costs |
| **Quality Performance** | Zero critical defects | Bug tracking system |
| **Stakeholder Satisfaction** | > 4.0/5.0 rating | Post-project survey |

### 2. SYSTEM PERFORMANCE KPIs

| KPI | Target | Measurement Period |
|-----|--------|--------------------|
| **System Availability** | 99.5% uptime | Monthly |
| **Response Time** | < 3 seconds | Real-time monitoring |
| **User Adoption Rate** | > 80% active users | Monthly |
| **Data Accuracy** | 99.5% accuracy | Weekly validation |

### 3. BUSINESS IMPACT METRICS

| Metric | Baseline | Target Improvement |
|--------|----------|-------------------|
| **Order Processing Time** | 30 minutes | 15 minutes (50% reduction) |
| **Inventory Accuracy** | 85% | 99% |
| **Customer Response Time** | 2 hours | 30 minutes |
| **Reporting Efficiency** | 4 hours | 15 minutes |

---

## CONCLUSION

Project Charter dan Plan ini menyediakan roadmap yang komprehensif untuk pengembangan SATRIAMART Integrated Management System. Dengan timeline 7 minggu, budget Rp 50 juta, dan team yang dedicated, project ini diharapkan dapat memberikan significant value kepada SATRIAMART dalam meningkatkan operational efficiency dan business growth.

**Next Steps:**
1. ✅ Stakeholder approval untuk project charter
2. ✅ Team assembly dan resource allocation
3. ✅ Detailed requirements gathering
4. ✅ Technical architecture finalization
5. ✅ Development phase initiation

---

**Document Control:**
- **Version:** 1.0
- **Date Created:** [Current Date]
- **Created By:** [Nama Mahasiswa]
- **Approved By:** [Dosen Pengampu]
- **Next Review:** [Weekly Reviews]
